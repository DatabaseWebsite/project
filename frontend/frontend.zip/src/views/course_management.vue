<template>  
  <el-container>
    <el-header style="text-align: right; font-size: 12px"> 
      <el-button  link type="primary" size="small" @click="dialogVisible = true">  
            添加课程 
          </el-button> 
      
      
    </el-header> 
    <el-main>  
      <courseForm v-for="(item, index) in course_info" :key="index" :item="item" />
    </el-main>  
  </el-container>  
  <el-dialog  
        v-model="dialogVisible"  
        title="Tips"  
        width="60%">  
         
        <el-form :model="course" ref="courseRef">    
          <el-form-item label="course_name" prop="name">  
            <el-input v-model="course.name"></el-input>  
          </el-form-item>     
          <el-form-item label="duration" prop="duration">  
            <el-input v-model="course.duration"></el-input>  
          </el-form-item>    
          <el-form-item label="description" prop="description">  
            <el-input v-model="course.description"></el-input>  
          </el-form-item>   
        </el-form>    
      
        
      <template #footer>  
      <span class="dialog-footer">  
        <el-button @click=cancelDialog()>Cancel</el-button>  
        <el-button type="primary" @click=confirmDialog()>  Confirm  </el-button>  
      </span>  
      </template>  
      </el-dialog>
</template>  
  
<script lang="ts">  
import { create_course_api, all_course_info_api } from "@/api/api.ts";  
import courseForm from "@/components/course_management/courseForm.vue";  
import { ElContainer, ElHeader, ElMain } from "element-plus";  
  
export default {  
  name: "course_management",  
  components: { courseForm },  
  data() {
  return {
    dialogVisible: false,
    course_info: [], // Initialize as an empty array
    course: {
      name: "",
      duration: "", // Add other properties if needed
      description: ""
    },
    try_course: "1234",
    };
  }, 
  created() {
    this.handleLogin();
  }, 
  methods: {  
    async handleLogin() {  
      try {  
        // Call the API  
        let info = await all_course_info_api();  
  
        // Update the data property  
        this.course_info = info.data.result;  
  
        console.log("all course api call successful" ,this.course_info);  
      } catch (error) {  
        console.error("Error calling API:", error);  
      }  
    },
    async addCourse() {
      
      await this.$refs.courseRef.validate(async (valid) => {  
        if (valid) {  
          console.log("success", this.course.name);
          await create_course_api(this.course.name);
          await this.handleLogin();
          
        } else {  
          console.log('提交失败');  
        }  
      });  
    },
    cancelDialog() { // 打开对话框的方法    
      this.dialogVisible = false;// 检查值是否被正确修改为true
    },
    confirmDialog() {
      this.addCourse();
      this.dialogVisible = false;
    },
  },  
};  
</script>  
  
<style scoped>  
 
</style>